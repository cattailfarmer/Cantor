Cantor provider-free portable release bundle candidate

Profile: cantor-provider-free-portable-release-bundle/0.1
Source commit: 04937d5e13bebcd5a2650a9064275c9f3c680b28
Target: windows-x86_64

Contents: cantor.exe, cantor-corpus.exe, cantord.exe, cantorctl.exe, and bundle-manifest.json.
Verification: use scripts/verify_cantor_provider_free_portable_release_bundle.ps1 with the companion evidence JSON in the governed source repository.

This archive is not an installer. Verification does not extract or execute it.
No production trust, secret, configuration, provider, persistence, effect, remote, FPGA, Minecraft, operator-product, or production authority is granted.
